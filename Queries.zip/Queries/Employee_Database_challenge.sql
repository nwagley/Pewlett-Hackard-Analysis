-- Retrieve the emp_no, first_name, and last_name columns from the Employees table.
select emp_no, first_name, last_name from employees;
--Retrieve the title, from_date, and to_date columns from the Titles table.
--Create a new table using the INTO clause.
select title, from_date, to_date from titles;
--Create a new table using the INTO clause.
--Join both tables on the primary key.
--Filter the data on the birth_date column to retrieve the employees who were born between 1952 and 1955. 
--Then, order by the employee number.
--Export the Retirement Titles table from the previous step as retirement_titles.csv and save it to your Data folder in the Pewlett-Hackard-Analysis folder.
select emp.emp_no, emp.first_name, emp.last_name, t.title, t.from_date, t.to_date
into retirement_titles
from employees as emp
inner join titles as t 
on emp.emp_no = t.emp_no
where emp.birth_date between '1952-01-01' and '1955-01-01'
order by t.emp_no ;
--drop table retirement_titles
select * from retirement_titles

--Retrieve the employee number, first and last name, and title columns from the Retirement Titles table.
--These columns will be in the new table that will hold the most recent title of each employee.
--Use the DISTINCT ON statement to retrieve the first occurrence of the employee number for each set of rows defined by the ON () clause.
-- Use Dictinct with Orderby to remove duplicate rows
SELECT DISTINCT ON (emp_no)emp_no,
first_name,
last_name,
title

INTO Unique_Emp
FROM retirement_titles
ORDER BY emp_no asc , to_date DESC;
select * from unique_emp

--First, retrieve the number of titles from the Unique Titles table.
--Then, create a Retiring Titles table to hold the required information.
--Group the table by title, then sort the count column in descending order.

SELECT COUNT(emp.title) as ct, emp.title 
INTO retiring_titles
FROM unique_emp as emp
--LEFT JOIN titles as ti
--ON emp.emp_no = ti.emp_no
GROUP BY emp.title
ORDER BY ct desc; 

select * from retiring_titles

--deliverable 2  
-- Mentorship table 
SELECT DISTINCT ON (emp.emp_no)emp.emp_no,
	emp.first_name, emp.last_name, emp.birth_date, de.from_date, de.to_date, ts.title 
INTO mentorship_eligibility
FROM employees AS emp 
INNER JOIN dept_emp AS de 
ON emp.emp_no = de.emp_no
INNER JOIN  titles AS ts 
ON emp.emp_no = ts.emp_no 
WHERE (emp.birth_date BETWEEN '1965-01-01' AND '1965-12-31')
AND (de.to_date = '9999-01-01')
ORDER BY emp.emp_no;

select * from mentorship_eligibility 